//
//  SpecHelper.h
//  libPusher
//
//  Created by Luke Redpath on 25/01/2012.
//  Copyright (c) 2012 LJR Software Limited. All rights reserved.
//

#import "Kiwi.h"
#import "PTPusher.h"

@class PTPusherEvent;

PTPusherEvent *anEventNamed(NSString *name);
