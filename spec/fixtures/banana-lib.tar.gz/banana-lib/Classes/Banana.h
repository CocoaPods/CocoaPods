
#import <Foundation/Foundation.h>

/** Bananas are cool */
@interface BananaObj : NSObject
@end