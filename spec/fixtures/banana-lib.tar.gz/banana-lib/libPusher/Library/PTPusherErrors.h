//
//  PTPusherErrors.h
//  libPusher
//
//  Created by Luke Redpath on 14/08/2011.
//  Copyright 2011 LJR Software Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

enum {
  PTPusherSubscriptionError = 0,
  PTPusherSubscriptionUnknownAuthorisationError
};
